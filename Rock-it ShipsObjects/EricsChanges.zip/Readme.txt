References:
Wrapping
http://masteringcoronasdk.com/free-corona-sdk-tutorial/wrapping-an-object-to-the-other-side/?category_name=free-corona-sdk-tutorial%2F

Base Game & Scenes
https://docs.coronalabs.com/guide/programming/02/index.html

Asteroids and Ship Place Holders:
https://docs.coronalabs.com/guide/programming/02/index.html

Background:
https://www.wallpapersafari.com/download/0Fw8gp/

Possible Music:
8-Bit Holst
https://www.youtube.com/watch?v=rcKoleYeAaU

8-Bit Asteroid (Star Wars Episode V)
https://www.youtube.com/watch?v=1Mqc-z2HJW0